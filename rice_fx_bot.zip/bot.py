"""
RICE FX TRADING — Telegram bot (aiogram 3, async)
Menyu: VIP signal, Bepul signal, Kurslar, Aloqa, $50 bonus
Admin: /free, /vip, /broadcast, /addvip, /stats
"""
import asyncio
import logging
import os
import time

import aiosqlite
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import (
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramRetryAfter,
)
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}
FREE_CHANNEL_URL = os.getenv("FREE_CHANNEL_URL", "https://t.me/your_free_channel")
VIP_CHANNEL_URL = os.getenv("VIP_CHANNEL_URL", "https://t.me/+your_vip_invite")
CONTACT_URL = os.getenv("CONTACT_URL", "https://t.me/your_username")
BONUS_URL = os.getenv(
    "BONUS_URL", "https://client-lc.born2trade.com/links/go/14"
)
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()
DB_PATH = os.getenv("DB_PATH", "ricefx.db")
BRAND = "RICE FX TRADING"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("ricefx")
router = Router()
db: aiosqlite.Connection

RISK = "\n\n<i>⚠️ Treyding xavf bilan bog'liq. Signallar moliyaviy maslahat emas.</i>"

# ───────────────────────── DATABASE ─────────────────────────


async def init_db() -> None:
    global db
    db = await aiosqlite.connect(DB_PATH)
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA synchronous=NORMAL")
    await db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY,
            name TEXT, username TEXT,
            joined INTEGER, vip_until INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS signals(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT, text TEXT, ts INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_users_vip ON users(vip_until);
        CREATE INDEX IF NOT EXISTS idx_sig_kind ON signals(kind, id DESC);
        """
    )
    await db.commit()


async def upsert_user(m: Message) -> None:
    u = m.from_user
    await db.execute(
        """INSERT INTO users(id,name,username,joined) VALUES(?,?,?,?)
           ON CONFLICT(id) DO UPDATE SET name=excluded.name,
           username=excluded.username, active=1""",
        (u.id, u.full_name, u.username, int(time.time())),
    )
    await db.commit()


async def is_vip(uid: int) -> bool:
    async with db.execute("SELECT vip_until FROM users WHERE id=?", (uid,)) as c:
        row = await c.fetchone()
    return bool(row and row[0] > time.time())


async def last_signal(kind: str) -> str | None:
    async with db.execute(
        "SELECT text FROM signals WHERE kind=? ORDER BY id DESC LIMIT 1", (kind,)
    ) as c:
        row = await c.fetchone()
    return row[0] if row else None


# ───────────────────────── KEYBOARDS ─────────────────────────


def main_menu() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if WEBAPP_URL:
        b.button(text="🚀 Ilovani ochish", web_app=WebAppInfo(url=WEBAPP_URL))
    b.button(text="👑 VIP Signal", callback_data="vip")
    b.button(text="🆓 Bepul Signal", callback_data="free")
    b.button(text="🎓 Kurslar", callback_data="courses")
    b.button(text="📞 Aloqa", callback_data="contact")
    b.button(text="🎁 $50 Bonus olish", url=BONUS_URL)
    b.adjust(*((1, 2, 2, 1) if WEBAPP_URL else (2, 2, 1)))
    return b.as_markup()


def back_kb(*extra) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for text, url in extra:
        b.button(text=text, url=url)
    b.button(text="⬅️ Orqaga", callback_data="home")
    b.adjust(1)
    return b.as_markup()


WELCOME = (
    f"🌾 <b>{BRAND}</b>ga xush kelibsiz!\n\n"
    "📊 Aniq forex signallar\n"
    "🎓 Treyding kurslari\n"
    "🎁 Ro'yxatdan o'ting va <b>$50 bonus</b> oling\n\n"
    "Quyidagi menyudan kerakli bo'limni tanlang 👇"
)


async def show(cq: CallbackQuery, text: str, kb: InlineKeyboardMarkup) -> None:
    try:
        await cq.message.edit_text(text, reply_markup=kb, disable_web_page_preview=True)
    except TelegramBadRequest:
        pass  # "message is not modified" yoki eski xabar
    await cq.answer()


# ───────────────────────── USER HANDLERS ─────────────────────────


@router.message(CommandStart())
async def start(m: Message) -> None:
    await upsert_user(m)
    await m.answer(WELCOME, reply_markup=main_menu())


@router.message(Command("menu"))
async def menu_cmd(m: Message) -> None:
    await m.answer(WELCOME, reply_markup=main_menu())


@router.callback_query(F.data == "home")
async def home(cq: CallbackQuery) -> None:
    await show(cq, WELCOME, main_menu())


@router.callback_query(F.data == "free")
async def free(cq: CallbackQuery) -> None:
    sig = await last_signal("free")
    text = "🆓 <b>Bepul signallar</b>\n\n"
    text += (
        f"📌 <b>Oxirgi signal:</b>\n{sig}\n\n"
        if sig
        else "Hozircha yangi signal yo'q.\n\n"
    )
    text += "Barcha bepul signallar kanalimizda 👇" + RISK
    await show(cq, text, back_kb(("📢 Bepul kanalga o'tish", FREE_CHANNEL_URL)))


@router.callback_query(F.data == "vip")
async def vip(cq: CallbackQuery) -> None:
    if await is_vip(cq.from_user.id):
        sig = await last_signal("vip")
        text = "👑 <b>VIP a'zosiz!</b>\n\n"
        text += f"📌 <b>Oxirgi VIP signal:</b>\n{sig}\n\n" if sig else ""
        text += "Barcha VIP signallar yopiq kanalda 👇" + RISK
        kb = back_kb(("👑 VIP kanalga o'tish", VIP_CHANNEL_URL))
    else:
        text = (
            "👑 <b>VIP Signal</b>\n\n"
            "✅ Kuniga bir nechta yuqori aniqlikdagi signal\n"
            "✅ Entry, Stop Loss va Take Profit aniq ko'rsatiladi\n"
            "✅ Shaxsiy yordam va tahlillar\n"
            "✅ Yopiq VIP kanal\n\n"
            "VIP ga ulanish uchun admin bilan bog'laning 👇" + RISK
        )
        kb = back_kb(("💬 VIP olish", CONTACT_URL))
    await show(cq, text, kb)


@router.callback_query(F.data == "courses")
async def courses(cq: CallbackQuery) -> None:
    text = (
        "🎓 <b>Treyding kurslari</b>\n\n"
        "📘 Boshlang'ich — forex asoslari\n"
        "📗 O'rta — texnik tahlil, risk menejment\n"
        "📕 Professional — strategiyalar va psixologiya\n\n"
        "Narx va jadval uchun admin bilan bog'laning 👇"
    )
    await show(cq, text, back_kb(("💬 Kursga yozilish", CONTACT_URL)))


@router.callback_query(F.data == "contact")
async def contact(cq: CallbackQuery) -> None:
    text = (
        f"📞 <b>Aloqa — {BRAND}</b>\n\n"
        "Savollaringiz bo'lsa, adminga yozing.\n"
        "🕐 Javob: har kuni 24/7"
    )
    await show(cq, text, back_kb(("✍️ Adminga yozish", CONTACT_URL)))


# ───────────────────────── ADMIN ─────────────────────────


def admin_only(m: Message) -> bool:
    return m.from_user.id in ADMIN_IDS


async def broadcast(bot: Bot, ids: list[int], text: str, admin_id: int) -> None:
    sent = failed = 0
    sem_delay = 1 / 25  # ~25 xabar/soniya (Telegram limiti 30)
    for uid in ids:
        try:
            await bot.send_message(uid, text, disable_web_page_preview=True)
            sent += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
            try:
                await bot.send_message(uid, text)
                sent += 1
            except Exception:
                failed += 1
        except TelegramForbiddenError:
            failed += 1
            await db.execute("UPDATE users SET active=0 WHERE id=?", (uid,))
        except Exception:
            failed += 1
        await asyncio.sleep(sem_delay)
    await db.commit()
    await bot.send_message(admin_id, f"✅ Yuborildi: {sent}\n❌ Xato: {failed}")


async def _ids(vip_only: bool) -> list[int]:
    q = "SELECT id FROM users WHERE active=1"
    args: tuple = ()
    if vip_only:
        q += " AND vip_until>?"
        args = (int(time.time()),)
    async with db.execute(q, args) as c:
        return [r[0] for r in await c.fetchall()]


async def _publish(m: Message, bot: Bot, kind: str, text: str, vip_only: bool) -> None:
    await db.execute(
        "INSERT INTO signals(kind,text,ts) VALUES(?,?,?)", (kind, text, int(time.time()))
    )
    await db.commit()
    ids = await _ids(vip_only)
    await m.answer(f"📤 {len(ids)} ta foydalanuvchiga yuborilmoqda...")
    asyncio.create_task(
        broadcast(bot, ids, f"📊 <b>{kind.upper()} SIGNAL</b>\n\n{text}", m.from_user.id)
    )


@router.message(Command("free"))
async def cmd_free(m: Message, command: CommandObject, bot: Bot) -> None:
    if not admin_only(m):
        return
    if not command.args:
        return await m.answer("Foydalanish: /free signal matni")
    await _publish(m, bot, "free", command.args, vip_only=False)


@router.message(Command("vip"))
async def cmd_vip(m: Message, command: CommandObject, bot: Bot) -> None:
    if not admin_only(m):
        return
    if not command.args:
        return await m.answer("Foydalanish: /vip signal matni")
    await _publish(m, bot, "vip", command.args, vip_only=True)


@router.message(Command("broadcast"))
async def cmd_broadcast(m: Message, command: CommandObject, bot: Bot) -> None:
    if not admin_only(m) or not command.args:
        return
    ids = await _ids(False)
    await m.answer(f"📤 {len(ids)} ta foydalanuvchiga yuborilmoqda...")
    asyncio.create_task(broadcast(bot, ids, command.args, m.from_user.id))


@router.message(Command("addvip"))
async def cmd_addvip(m: Message, command: CommandObject) -> None:
    if not admin_only(m):
        return
    try:
        uid, days = (int(x) for x in command.args.split())
    except Exception:
        return await m.answer("Foydalanish: /addvip USER_ID KUN")
    until = int(time.time()) + days * 86400
    await db.execute("UPDATE users SET vip_until=? WHERE id=?", (until, uid))
    await db.commit()
    await m.answer(f"✅ {uid} — {days} kunga VIP berildi")


@router.message(Command("stats"))
async def cmd_stats(m: Message) -> None:
    if not admin_only(m):
        return
    async with db.execute(
        "SELECT COUNT(*), SUM(active), SUM(vip_until>?) FROM users", (int(time.time()),)
    ) as c:
        total, active, vips = await c.fetchone()
    await m.answer(
        f"📊 Jami: {total}\n✅ Faol: {active or 0}\n👑 VIP: {vips or 0}"
    )


# ───────────────────────── RUN ─────────────────────────


async def main() -> None:
    await init_db()
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    log.info("%s bot ishga tushdi", BRAND)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    while True:  # kutilmagan xatoda avtomatik qayta ishga tushadi
        try:
            asyncio.run(main())
        except (KeyboardInterrupt, SystemExit):
            break
        except Exception:
            log.exception("Bot qulab tushdi, 5 soniyadan keyin qayta ishga tushadi")
            time.sleep(5)
